
import express from 'express'
import dotenv from 'dotenv'
import { answer } from './agent.js'

dotenv.config()
const app = express()
app.use(express.json())

const PORT = process.env.PORT || 3000

app.get('/', (_req, res) => {
  res.send('ChainOpera Agent is running. POST /agent/ask {question}')
})

app.post('/agent/ask', async (req, res) => {
  try {
    const { question } = req.body || {}
    if (!question) return res.status(400).json({ error: 'Missing {question}' })
    const result = await answer(question)
    res.json(result)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`)
})
