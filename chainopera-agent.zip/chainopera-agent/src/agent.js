
import fs from 'fs'
import path from 'path'
import OpenAI from 'openai'
import dotenv from 'dotenv'
dotenv.config()

const EMBEDDING_MODEL = process.env.EMBEDDING_MODEL || 'text-embedding-3-small'
const CHAT_MODEL = process.env.CHAT_MODEL || 'gpt-4o-mini'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

const KB_DIR = path.join(process.cwd(), 'kb')
const KB_INDEX = path.join(KB_DIR, 'index.json')

function dot(a, b) {
  let s = 0
  for (let i = 0; i < a.length; i++) s += a[i] * b[i]
  return s
}
function norm(a) {
  return Math.sqrt(dot(a, a))
}
function cosineSim(a, b) {
  return dot(a, b) / (norm(a) * norm(b) + 1e-9)
}

export async function embed(text) {
  const res = await openai.embeddings.create({
    model: EMBEDDING_MODEL,
    input: text
  })
  return res.data[0].embedding
}

export function loadKB() {
  if (!fs.existsSync(KB_INDEX)) {
    throw new Error('KB index not found. Run `npm run ingest` first.')
  }
  const raw = fs.readFileSync(KB_INDEX, 'utf-8')
  return JSON.parse(raw)
}

export async function retrieve(queryEmbedding, topK = 6) {
  const kb = loadKB()
  const scored = kb.map((item) => ({
    ...item,
    score: cosineSim(queryEmbedding, item.embedding)
  }))
  scored.sort((a, b) => b.score - a.score)
  return scored.slice(0, topK)
}

export async function answer(question) {
  const qEmbedding = await embed(question)
  const top = await retrieve(qEmbedding, 6)

  const context = top.map((t, i) => `[#${i+1}] ${t.text.trim()}`).join('\n\n')
  const sys = `Bạn là một trợ lý am hiểu về ChainOpera AI (white paper & roadmap). 
Trả lời NGẮN GỌN bằng tiếng Việt, dựa vào ngữ cảnh dưới đây. 
Nếu thiếu thông tin, nói rõ "không thấy trong roadmap". Tránh đoán mò. 
Khi nói về mốc thời gian, dùng định dạng "YYYY Qn" hoặc "Tháng YYYY" nếu có.`

  const user = `Câu hỏi: ${question}
---
Ngữ cảnh:
${context}`

  const completion = await openai.chat.completions.create({
    model: CHAT_MODEL,
    messages: [
      { role: 'system', content: sys },
      { role: 'user', content: user }
    ],
    temperature: 0.2
  })

  const text = completion.choices[0].message.content
  return { text, references: top.map((t) => ({ source: t.source, score: t.score })) }
}
