
import fs from 'fs'
import path from 'path'
import dotenv from 'dotenv'
import OpenAI from 'openai'

dotenv.config()

const EMBEDDING_MODEL = process.env.EMBEDDING_MODEL || 'text-embedding-3-small'
const KB_DIR = path.join(process.cwd(), 'kb')
const KB_FILE = path.join(KB_DIR, 'chainopera_roadmap.md')
const KB_INDEX = path.join(KB_DIR, 'index.json')

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

function chunkText(text, maxLen = 1200) {
  const paras = text.split(/\n\n+/).map(s => s.trim()).filter(Boolean)
  const chunks = []
  let buf = ''

  for (const p of paras) {
    if ((buf + '\n\n' + p).length > maxLen && buf) {
      chunks.push(buf.trim())
      buf = p
    } else {
      buf = buf ? (buf + '\n\n' + p) : p
    }
  }
  if (buf) chunks.push(buf.trim())
  return chunks
}

async function embedBatch(chunks) {
  const res = await openai.embeddings.create({
    model: EMBEDDING_MODEL,
    input: chunks
  })
  return res.data.map((d, i) => ({
    embedding: d.embedding,
    text: chunks[i],
    source: 'kb/chainopera_roadmap.md'
  }))
}

async function main() {
  if (!fs.existsSync(KB_FILE)) {
    throw new Error('KB file not found: ' + KB_FILE)
  }
  const raw = fs.readFileSync(KB_FILE, 'utf-8')
  const chunks = chunkText(raw, 1400)
  console.log('Chunks:', chunks.length)

  const items = await embedBatch(chunks)

  if (!fs.existsSync(KB_DIR)) fs.mkdirSync(KB_DIR, { recursive: true })
  fs.writeFileSync(KB_INDEX, JSON.stringify(items, null, 2), 'utf-8')
  console.log('Wrote', KB_INDEX)
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
