
ChainOpera AI - White Paper / Roadmap (Tóm lược nội dung người dùng cung cấp)

Last Update: August 2025

Thesis chính:
- AGI không đến từ một mô hình khổng lồ duy nhất, mà từ hợp tác giữa nhiều mô hình/agent chuyên biệt (multimodal, multi-agent).
- Hạ tầng & kinh tế phi tập trung là lựa chọn tất yếu: cộng đồng đóng góp GPU, mô hình, dữ liệu; hệ thống phải bền vững, minh bạch, chi phí hiệu quả.
- Ứng dụng trọng tâm trong Crypto/FinTech: giúp người dùng tối ưu lợi nhuận, đơn giản hóa công cụ tài chính, đảm bảo an toàn vốn & hệ thống.

Các giai đoạn (Stage 1 → 4):
- Stage 1 (2025): DePIN GPU network, federated learning, distributed inference/training, model router; nhà cung cấp GPU/model API nhận on-chain incentives.
- Stage 2: AI Social Network + Marketplace + multi-agent workflows; CoAI Protocol; thuật toán stablecoin credit exchange; matching cung–cầu.
- Stage 3 (2024–2025 nêu trong hình minh họa; theo text là sau Stage 2): Mở rộng DeFi, RWA, PayFi, KOL; Agent-to-Agent Payment & Wallet; tokenized financing; launchpad/leaderboard.
- Stage 4 (2026+): Autonomous AI subnets; tokenomics cho từng subnet; mainnet token support; hướng đến Physical AI.

AI Super App Layer (mốc chính):
- 2025 Q1–Q2: AI Terminal (iOS/Web), Agent Marketplace, Agent Social Network, Agent Router (Coco).
- 2025 Q3: Idea–Dev Matching; Trader Agents (Automated Trading, Strategy Agent); KOL Agents; Use-to-Earn.
- 2025 Q4: Proof of Second Me.
- 2026 Q1+: AI Trader Twin, multi-model output scoring, data contribution, AI Marketplace (mua asset AI-generated), AI Social Feed, AI Phone, Physical AI.

Agent Developer Platform:
- 2025 Q2: Developer Platform (Prompt, No-code, API, Open-source framework), MCP, RAG/KB, AgentOpera framework, deploy & publish.
- 2025 Q3: Incentive Economics; open-source AgentOpera; templates (Trading Strategy, KOL), Traders earn per transactions.
- 2026 Q1+: mở rộng template, creator hub.

Decentralized Model & GPU Layer:
- 2025 Q1: Decentralized Model & GPU Platform; Federated learning lib (GPU/phone/IoT).
- 2025 Q3: Model Router.
- 2025 Q4: Verifiable Inference (phối hợp EigenLayer).
- 2026 Q1+: multimodal routing, on-chain model incentives; cộng đồng đào tạo LLM >100B tham gia từ 2025 Q4, liên tục online training.

Blockchain Protocol Layer:
- 2025 Q2: Credit system liên kết user–dev–GPU miner.
- 2025 Q3: Agent Leaderboard (fair distribution).
- 2025 Q4: Algorithmic Stablecoin Credit Exchange.
- 2026 Q1+: Subnetwork tokenomics; mainnet token support; multi-subnet collaboration.

Lưu ý về Token/TGE:
- Whitepaper/roadmap không nêu ngày TGE cụ thể. Có đề cập on-chain incentives (2025), tokenized financing và mainnet token support (2025–2026+), nhưng **không chỉ định lịch TGE**.
